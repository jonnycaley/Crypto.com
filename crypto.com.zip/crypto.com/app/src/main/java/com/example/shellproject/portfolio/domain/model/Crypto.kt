package com.example.shellproject.portfolio.domain.model

data class Crypto(
    val name: String,
    val symbol: String,
    val imageUrl: String,
    val amount: Double,
    val usdValue: Float
)