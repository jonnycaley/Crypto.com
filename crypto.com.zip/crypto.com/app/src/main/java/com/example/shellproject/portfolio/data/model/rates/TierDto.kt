package com.example.shellproject.portfolio.data.model.rates

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class TierDto(
    @SerializedName("from_currency") val fromCurrency: String,
    @SerializedName("rates") val rateDtos: List<RateDto>,
    @SerializedName("time_stamp") val timeStamp: Int,
    @SerializedName("to_currency") val toCurrency: String
): Parcelable