package com.example.shellproject.portfolio.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.shellproject.common.network.AppSchedulers
import com.example.shellproject.portfolio.domain.model.Wallet
import com.example.shellproject.portfolio.domain.usecase.GetWallet
import com.example.shellproject.utils.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import io.reactivex.rxjava3.disposables.CompositeDisposable
import io.reactivex.rxjava3.kotlin.addTo
import javax.inject.Inject

@HiltViewModel
class WalletViewModel @Inject constructor(
    val getWallet: GetWallet,
    val schedulers: AppSchedulers
) : ViewModel() {

    private var disposable = CompositeDisposable()

    val wallet: LiveData<Result<Wallet>>
        get() = _wallet

    private var _wallet = MutableLiveData<Result<Wallet>>()

    init {
        loadWallet()
    }

    fun loadWallet() {
        getWallet()
            .subscribeOn(schedulers.io)
            .observeOn(schedulers.mainThread)
            .doOnSubscribe {
                _wallet.value = Result.loading()
            }
            .subscribe({ wallet ->
                _wallet.value = Result.success(wallet)
            }, {
                _wallet.value = Result.error("An error occured")
            })
            .addTo(disposable)
    }

    override fun onCleared() {
        super.onCleared()
        disposable.dispose()
    }
}