package com.example.shellproject.portfolio.data.model.currencies

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class CurrencyDto(
    @SerializedName("blockchain_symbol") val blockchainSymbol: String,
    @SerializedName("code") val code: String,
    @SerializedName("coin_id") val coinId: String,
    @SerializedName("colorful_image_url") val colorfulImageUrl: String,
    @SerializedName("contract_address") val contractAddress: String,
    @SerializedName("deposit_address_tag_name") val depositAddressTagName: String,
    @SerializedName("deposit_address_tag_type") val depositAddressTagType: String,
    @SerializedName("display_decimal") val displayDecimal: Int,
    @SerializedName("explorer") val explorer: String,
    @SerializedName("gas_limit") val gasLimit: Int,
    @SerializedName("gray_image_url") val grayImageUrl: String,
    @SerializedName("has_deposit_address_tag") val hasDepositAddressTag: Boolean,
    @SerializedName("is_erc20") val isErc20: Boolean,
    @SerializedName("min_balance") val minBalance: Int,
    @SerializedName("name") val name: String,
    @SerializedName("num_confirmation_required") val numConfirmationRequired: Int,
    @SerializedName("supports_legacy_address") val supportLegacyAddress: Boolean,
    @SerializedName("symbol") val symbol: String,
    @SerializedName("token_decimal") val tokenDecimal: Int,
    @SerializedName("token_decimal_value") val tokenDecimalValue: String,
    @SerializedName("trading_symbol") val tradingSymbol: String,
    @SerializedName("withdrawal_eta") val withdrawalEta: List<String>
): Parcelable