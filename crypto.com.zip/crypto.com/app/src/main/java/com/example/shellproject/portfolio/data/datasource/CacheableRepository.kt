package com.example.shellproject.portfolio.data.datasource

import android.content.Context
import com.google.gson.Gson
import io.reactivex.rxjava3.core.Single

abstract class CacheableRepository<T> constructor(
    private val file: Int,
    private val context: Context,
    private val tClass: Class<T>
) {
    private var cache: T? = null

    fun getData(): Single<T> {
        return Single.just(cache ?: readDataFromFile().also { cache = it })
    }

    private fun readDataFromFile(): T {
        val reader = context.resources.openRawResource(file)
            .bufferedReader()
        val walletString = reader.use { it.readText() }
        reader.close()
        return Gson().fromJson(walletString, tClass)
    }
}