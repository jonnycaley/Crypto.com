package com.example.shellproject.portfolio.data.datasource

import android.content.Context
import com.example.shellproject.R
import com.example.shellproject.portfolio.data.model.wallet.WalletDto
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WalletRepository @Inject constructor(
    @ApplicationContext private val context: Context
): CacheableRepository<WalletDto>(R.raw.wallet_balance_json, context, WalletDto::class.java)