package com.example.shellproject.portfolio.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.shellproject.databinding.CryptoItemBinding
import com.example.shellproject.portfolio.domain.model.Crypto

class WalletAdapter(
    private val cryptos: List<Crypto>
) : RecyclerView.Adapter<WalletAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding = CryptoItemBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(itemBinding)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(cryptos[position])
    }
    override fun getItemCount(): Int {
        return cryptos.size
    }

    inner class ViewHolder(
        private val binding: CryptoItemBinding
        ): RecyclerView.ViewHolder(binding.root) {
        fun bind(crypto: Crypto) {
            with(crypto) {
                binding.name.text = name
                binding.amount.text = "${WalletPresentationMapper.formatAmount(amount)} ${symbol.uppercase()}"
                binding.usdValue.text = "$ ${WalletPresentationMapper.formatUsdValue(usdValue)}"
                Glide
                    .with(binding.root.context)
                    .load(imageUrl)
                    .into(binding.image)
            }
        }
    }
}