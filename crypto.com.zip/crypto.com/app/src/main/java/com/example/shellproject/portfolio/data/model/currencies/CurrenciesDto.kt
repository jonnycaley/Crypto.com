package com.example.shellproject.portfolio.data.model.currencies

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class CurrenciesDto(
    @SerializedName("currencies") val currencyDtos: List<CurrencyDto>,
    @SerializedName("ok") val ok: Boolean,
    @SerializedName("total") val total: Int
): Parcelable