package com.example.shellproject.portfolio.domain.model

data class Wallet(
    val totalUsd: Float,
    val cryptos: List<Crypto>,
)