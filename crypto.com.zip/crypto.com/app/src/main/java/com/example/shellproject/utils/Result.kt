package com.example.shellproject.utils

/**
 * A generic class that holds a value with its loading status.
 * @param <T>
</T> */
data class Result<out T>(val status: Status, val data: T?, val message: String?) {
    companion object {
        fun <T> success(data: T?): Result<T> {
            return Result(Status.SUCCESS, data, null)
        }

        fun <T> error(msg: String): Result<T> {
            return Result(Status.ERROR, null, msg)
        }

        fun <T> loading(data: T? = null): Result<T> {
            return Result(Status.LOADING, data, null)
        }
    }

    fun isLoading(): Boolean {
        return status == Status.LOADING
    }

    fun isSuccess(): Boolean {
        return status == Status.SUCCESS
    }

    fun isError(): Boolean {
        return status == Status.ERROR
    }
}

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}