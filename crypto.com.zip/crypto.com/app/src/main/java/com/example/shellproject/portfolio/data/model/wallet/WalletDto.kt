package com.example.shellproject.portfolio.data.model.wallet

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class WalletDto(
    @SerializedName("ok") val ok: Boolean,
    @SerializedName("wallet") val cryptos: List<CryptoDto>,
    @SerializedName("warning") val warning: String
): Parcelable

