package com.example.shellproject.portfolio.data.model.rates

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class RatesDto(
    @SerializedName("ok") val ok: Boolean,
    @SerializedName("tiers") val tierDtos: List<TierDto>,
    @SerializedName("warning") val warning: String
): Parcelable