package com.example.shellproject.portfolio.data.model.wallet

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class CryptoDto(
    @SerializedName("currency") val currency: String,
    @SerializedName("amount") val amount: Double
): Parcelable