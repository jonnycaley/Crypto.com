package com.example.shellproject.portfolio.data.datasource

import android.content.Context
import com.example.shellproject.R
import com.example.shellproject.portfolio.data.model.rates.RatesDto
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RatesRepository @Inject constructor(
    @ApplicationContext private val context: Context
): CacheableRepository<RatesDto>(R.raw.live_rates_json, context, RatesDto::class.java)