package com.example.shellproject.portfolio.data.model.rates

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class RateDto(
    @SerializedName("amount") val amount: String,
    @SerializedName("rate") val rate: String
): Parcelable