package com.example.shellproject.portfolio.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.shellproject.databinding.PortfolioFragmentBinding
import com.example.shellproject.portfolio.domain.model.Wallet
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class WalletFragment : Fragment() {

    private var _binding: PortfolioFragmentBinding? = null
    private val binding get() = _binding!!

    private lateinit var walletAdapter: WalletAdapter

    private val viewModel: WalletViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = PortfolioFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.wallet.observe(viewLifecycleOwner) { wallet ->
            binding.error.isVisible = wallet.isError()

            binding.progress.isVisible = wallet.isLoading()

            binding.usd.isVisible = wallet.isSuccess()
            binding.walletListRecyclerview.isVisible = wallet.isSuccess()
            if (wallet.isSuccess()) {
                wallet.data?.let {
                    loadWallet(it)
                }
            }
        }

        binding.error.setOnClickListener {
            viewModel.loadWallet()
        }
    }

    private fun loadWallet(wallet: Wallet) {
        walletAdapter = WalletAdapter(wallet.cryptos)
        binding.usd.text = WalletPresentationMapper.formatTitle(wallet.totalUsd)

        with(binding.walletListRecyclerview) {
            adapter = walletAdapter
            setHasFixedSize(true)
            layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}