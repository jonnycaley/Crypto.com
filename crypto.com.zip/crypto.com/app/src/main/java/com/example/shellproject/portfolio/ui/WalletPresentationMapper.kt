package com.example.shellproject.portfolio.ui

import java.math.RoundingMode

object WalletPresentationMapper  {
    fun formatUsdValue(usdValue: Float): String {
        return if (usdValue % 1 == 00f) {
            usdValue.toInt().toString()
        } else {
            usdValue.toBigDecimal().setScale(2, RoundingMode.UP).toString()
        }
    }

    fun formatAmount(amount: Double): String {
        return if (amount % 1 == 00.0) {
            amount.toInt().toString()
        } else {
            amount.toString()
        }
    }
    fun formatTitle(totalUsd: Float): String {
        return "$ ${formatUsdValue(totalUsd)} USD"
    }
}