package com.example.shellproject.portfolio.domain.usecase

import com.example.shellproject.portfolio.data.datasource.CurrenciesRepository
import com.example.shellproject.portfolio.data.datasource.RatesRepository
import com.example.shellproject.portfolio.data.datasource.WalletRepository
import com.example.shellproject.portfolio.data.model.currencies.CurrenciesDto
import com.example.shellproject.portfolio.data.model.rates.RatesDto
import com.example.shellproject.portfolio.data.model.wallet.CryptoDto
import com.example.shellproject.portfolio.data.model.wallet.WalletDto
import com.example.shellproject.portfolio.domain.model.Crypto
import com.example.shellproject.portfolio.domain.model.Wallet
import io.reactivex.rxjava3.core.Single
import javax.inject.Inject

class GetWallet @Inject constructor(
    private val walletRepository: WalletRepository,
    private val currenciesRepository: CurrenciesRepository,
    private val ratesRepository: RatesRepository
) {
    operator fun invoke(): Single<Wallet> {
        return Single.zip(
            walletRepository.getData(),
            currenciesRepository.getData(),
            ratesRepository.getData()
        ) { wallet, currencies, rates ->
            val cryptos = getCrypto(wallet, currencies, rates)
            val totalUSDValue = cryptos.sumOf { it.usdValue.toDouble() }.toFloat()

            return@zip Wallet(
                totalUsd = totalUSDValue,
                cryptos = cryptos
            )
        }
    }

    private fun getCrypto(
        wallet: WalletDto,
        currencies: CurrenciesDto,
        rates: RatesDto
    ): List<Crypto> {
        return wallet.cryptos.map { crypto ->
            val valueOfOneCrypto = getValueOfOneCrypto(crypto, rates)
            val usdValueOfCrypto = (valueOfOneCrypto * crypto.amount).toFloat()

            val currencyDetail = currencies.currencyDtos.first { currencyDto ->
                currencyDto.coinId == crypto.currency
            }

            Crypto(
                name = currencyDetail.name,
                symbol = crypto.currency,
                imageUrl = currencyDetail.colorfulImageUrl,
                amount = crypto.amount,
                usdValue = usdValueOfCrypto
            )
        }
    }

    // this can be improved, instead of getting the first value we should get the
    // best rate given the amount of crypto the user has
    private fun getValueOfOneCrypto(
        crypto: CryptoDto,
        rates: RatesDto
    ): Double {
        return rates.tierDtos
            .first {
                it.fromCurrency == crypto.currency && it.toCurrency == "USD"
            }
            .rateDtos
            .first()
            .rate
            .toDouble()
    }
}