package com.example.shellproject.portfolio.data.datasource

import android.content.Context
import com.example.shellproject.R
import com.example.shellproject.portfolio.data.model.currencies.CurrenciesDto
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CurrenciesRepository @Inject constructor(
    @ApplicationContext private val context: Context
): CacheableRepository<CurrenciesDto>(R.raw.currencies_json, context, CurrenciesDto::class.java)